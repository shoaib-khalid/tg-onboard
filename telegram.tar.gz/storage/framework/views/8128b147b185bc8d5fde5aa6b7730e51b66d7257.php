<h1>Sorry</h1>
<p>Process Failed</p><?php /**PATH C:\Users\Dell-Admin\Documents\Projects\wrappers\tg-onboard\resources\views/failed.blade.php ENDPATH**/ ?>